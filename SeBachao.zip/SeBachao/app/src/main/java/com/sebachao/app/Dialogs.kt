package com.sebachao.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val elimMessages = listOf(
    "Bye bye bhai! Chai ka bill tumhara!",
    "Arre bhai! Limit se na bach paye!",
    "Pack your bags, the casino has spoken!",
    "Ab sidelines par chai banao sab ke liye!",
    "Better luck next deck!",
    "Cards never lie... you just did."
)
private val winMessages = listOf(
    "Jeet gaya re baba! Chai aaj tum pilao!",
    "Last one standing. Bilkul baadshah!",
    "Everyone else crashed. You survived the casino!",
    "Treat time: the losers are paying!",
    "You dodged the limit like a pro!"
)

@Composable
fun Bubble(text: String, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "bub")
    val dy by t.animateFloat(
        initialValue = 0f, targetValue = -8f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bubDy"
    )
    Box(modifier.graphicsLayer { translationY = dy }) {
        Box(Modifier.matchParentSize().offset(3.dp, 3.dp).background(Color.Black, RoundedCornerShape(18.dp)))
        Text(
            text, color = Dark, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center,
            modifier = Modifier
                .background(Cream, RoundedCornerShape(18.dp))
                .border(3.dp, Color.Black, RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun Modifier.shake(): Modifier {
    val t = rememberInfiniteTransition(label = "shake")
    val dx by t.animateFloat(
        initialValue = -8f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(260, easing = LinearEasing), RepeatMode.Reverse),
        label = "shakeDx"
    )
    return this.graphicsLayer { translationX = dx; rotationZ = dx / 3f }
}

@Composable
fun RoundDialog(state: GameState, onDismiss: () -> Unit, onSubmit: (Map<Int, Int>) -> String?) {
    val inputs = remember { mutableStateMapOf<Int, String>() }
    var error by remember { mutableStateOf<String?>(null) }
    var errorId by remember { mutableStateOf(-1) }
    var busy by remember { mutableStateOf(false) }
    val lastActive = state.active.lastOrNull()?.id ?: -1

    val submit: () -> Unit = {
        if (!busy) {
            busy = true
            val map = mutableMapOf<Int, Int>()
            var msg: String? = null
            for (p in state.active) {
                val n = inputs[p.id]?.toIntOrNull()
                if (n == null || n < 0) {
                    msg = "Enter a whole number (0 or more) for ${p.displayName}."
                    errorId = p.id
                    break
                }
                map[p.id] = n
            }
            if (msg != null) {
                error = msg
                busy = false
            } else {
                val r = onSubmit(map)
                if (r != null) {
                    error = r
                    errorId = -1
                    busy = false
                }
            }
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f),
            shape = RoundedCornerShape(24.dp),
            color = CardC, contentColor = Ink,
            border = BorderStroke(3.dp, Pink)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("ROUND ${state.round} - enter scores", color = Yellow, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("Whole numbers, 0 or more. OUT players are locked.", fontSize = 12.sp, color = Ink.copy(alpha = 0.8f))
                Spacer(Modifier.height(10.dp))
                Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState())) {
                    for (p in state.players) {
                        val out = state.isOut(p)
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(p.photo, p.id, 44.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.displayName, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(
                                    if (out) "OUT - ${p.total}" else "Total ${p.total}",
                                    fontSize = 11.sp, color = if (out) Red else Ink.copy(alpha = 0.7f)
                                )
                            }
                            OutlinedTextField(
                                value = if (out) "OUT" else inputs[p.id] ?: "",
                                onValueChange = { v ->
                                    inputs[p.id] = v.filter { it.isDigit() }.take(4)
                                    error = null
                                    errorId = -1
                                },
                                enabled = !out,
                                isError = errorId == p.id,
                                singleLine = true,
                                label = { Text(if (out) "Locked" else "Score") },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = if (p.id == lastActive) ImeAction.Done else ImeAction.Next
                                ),
                                keyboardActions = KeyboardActions(onDone = { submit() }),
                                modifier = Modifier.width(124.dp)
                            )
                        }
                    }
                }
                val err = error
                if (err != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(err, color = Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).height(52.dp),
                        border = BorderStroke(2.dp, Pink),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Pink)
                    ) { Text("Cancel") }
                    Button(
                        onClick = submit,
                        enabled = !busy,
                        modifier = Modifier.weight(1.4f).height(52.dp),
                        border = BorderStroke(3.dp, Color.Black),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Dark)
                    ) { Text("ADD ROUND", fontWeight = FontWeight.Black) }
                }
            }
        }
    }
}

@Composable
fun HistoryDialog(state: GameState, p: Player, onDismiss: () -> Unit) {
    val out = state.isOut(p)
    val rows = remember(p.history) {
        var run = 0
        p.history.map { e ->
            run += e.score
            Triple(e.round, e.score, run)
        }
    }
    val outRound = state.outRound(p)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.85f),
            shape = RoundedCornerShape(24.dp),
            color = CardC, contentColor = Ink,
            border = BorderStroke(3.dp, if (out) Red else Pink)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(p.photo, p.id, 64.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.displayName, fontSize = 24.sp, fontWeight = FontWeight.Black, color = Yellow, maxLines = 1)
                        Spacer(Modifier.height(4.dp))
                        StatusChip(out)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${p.total}", fontSize = 36.sp, fontWeight = FontWeight.Black, color = if (out) Red else Yellow)
                        Text("total / ${state.maxScore}", fontSize = 11.sp)
                    }
                }
                if (outRound != null) {
                    Spacer(Modifier.height(6.dp))
                    Text("Eliminated in round $outRound", color = Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().background(Color(0x33FF7AB6), RoundedCornerShape(10.dp)).padding(10.dp)) {
                    Text("ROUND", Modifier.weight(1f), fontWeight = FontWeight.Black, fontSize = 12.sp, color = Yellow)
                    Text("SCORE", Modifier.weight(1f), fontWeight = FontWeight.Black, fontSize = 12.sp, color = Yellow, textAlign = TextAlign.Center)
                    Text("TOTAL", Modifier.weight(1f), fontWeight = FontWeight.Black, fontSize = 12.sp, color = Yellow, textAlign = TextAlign.End)
                }
                if (rows.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("No rounds played yet.", color = Ink.copy(alpha = 0.8f))
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        itemsIndexed(rows) { i, r ->
                            val knockedOut = r.first == outRound
                            Row(
                                Modifier.fillMaxWidth()
                                    .background(
                                        when {
                                            knockedOut -> Color(0x44FF3B3B)
                                            i % 2 == 0 -> Color(0x11FFFFFF)
                                            else -> Color.Transparent
                                        }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                            ) {
                                Text("Round ${r.first}", Modifier.weight(1f), fontSize = 15.sp)
                                Text("+${r.second}", Modifier.weight(1f), fontSize = 15.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                                Text(
                                    if (knockedOut) "${r.third} OUT" else "${r.third}",
                                    Modifier.weight(1f), fontSize = 15.sp, textAlign = TextAlign.End,
                                    fontWeight = FontWeight.Black, color = if (knockedOut) Red else Yellow
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    border = BorderStroke(3.dp, Color.Black),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Dark)
                ) { Text("CLOSE", fontWeight = FontWeight.Black) }
            }
        }
    }
}

@Composable
fun EliminationDialog(state: GameState, names: List<String>, onDismiss: () -> Unit) {
    val msg = remember { elimMessages.random() }
    val slam = remember { Animatable(4f) }
    LaunchedEffect(Unit) {
        slam.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessLow))
    }
    val who = state.players.firstOrNull { it.displayName == names.firstOrNull() }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2)))) {
            Falling(1, Modifier.fillMaxSize())
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(10.dp))
                OutlineText(
                    "OUT!", 100.sp, Red, outline = 4.dp,
                    modifier = Modifier.graphicsLayer { scaleX = slam.value; scaleY = slam.value; rotationZ = -8f }
                )
                Spacer(Modifier.height(8.dp))
                Bubble(msg)
                if (state.stickersOn) {
                    Spacer(Modifier.height(14.dp))
                    StickerView(state, Slot.OUT, Modifier.size(width = 150.dp, height = 290.dp).shake())
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .background(CardC, RoundedCornerShape(18.dp))
                        .border(3.dp, Pink, RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (who != null) {
                        Avatar(who.photo, who.id, 52.dp, ring = Red)
                        Spacer(Modifier.width(10.dp))
                    }
                    Column {
                        Text(
                            if (names.size == 1) names[0].uppercase() + " IS OUT!" else names.joinToString(" & ").uppercase() + " ARE OUT!",
                            color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Black
                        )
                        if (who != null) {
                            Text(
                                "${who.total} / ${state.maxScore}: crossed the line!",
                                color = Red, fontWeight = FontWeight.Bold, fontSize = 13.sp
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    border = BorderStroke(3.dp, Color.Black),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Dark)
                ) { Text("RIP", fontWeight = FontWeight.Black, fontSize = 22.sp) }
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
fun WinnerDialog(state: GameState, onClose: () -> Unit, onNewGame: () -> Unit) {
    val winner = state.winner
    val msg = remember(winner?.id) {
        if (winner != null) winMessages.random() else "Sab limit par pohanch gaye! Total chaos, nobody wins."
    }
    val inf = rememberInfiniteTransition(label = "win")
    val pulse by inf.animateFloat(
        initialValue = 0.94f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulse"
    )
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg2, Bg1)))) {
            Rays(Modifier.fillMaxSize())
            Falling(0, Modifier.fillMaxSize())
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(8.dp))
                if (winner != null) {
                    Crown(Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse })
                    Avatar(winner.photo, winner.id, 130.dp, Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse }, ring = Amber)
                    Spacer(Modifier.height(12.dp))
                    OutlineText(
                        winner.displayName.uppercase() + " WINS!", 44.sp, Yellow, outline = 3.dp,
                        modifier = Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse }
                    )
                    Text("won the match with ${winner.total} points", color = Ink, fontSize = 14.sp)
                } else {
                    Text("🤝", fontSize = 90.sp, modifier = Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse })
                    OutlineText("IT'S A DRAW!", 44.sp, Yellow, outline = 3.dp)
                }
                Spacer(Modifier.height(12.dp))
                Bubble(msg)
                if (state.stickersOn) {
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        StickerView(state, Slot.WIN_L, Modifier.size(width = 96.dp, height = 200.dp).wiggle(1100, 4f))
                        StickerView(state, Slot.WIN_C, Modifier.size(width = 150.dp, height = 230.dp).wiggle(1100, 4f, 300))
                        StickerView(state, Slot.WIN_R, Modifier.size(width = 96.dp, height = 200.dp).wiggle(1100, 4f, 600))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Column(
                    Modifier.fillMaxWidth().background(Color(0x66000000), RoundedCornerShape(16.dp)).padding(12.dp)
                ) {
                    Text("FINAL SCORES", color = Yellow, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    for (p in state.players.sortedBy { it.total }) {
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(p.displayName, Modifier.weight(1f), color = Ink, maxLines = 1)
                            Text("${p.total}", color = if (state.isOut(p)) Red else Yellow, fontWeight = FontWeight.Black)
                            Spacer(Modifier.width(8.dp))
                            if (state.isOut(p)) StatusChip(true) else Text("🏆", fontSize = 16.sp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onClose,
                        modifier = Modifier.weight(1f).height(54.dp),
                        border = BorderStroke(3.dp, Color.Black),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Dark)
                    ) { Text("VIEW SCORES", fontWeight = FontWeight.Black) }
                    Button(
                        onClick = onNewGame,
                        modifier = Modifier.weight(1f).height(54.dp),
                        border = BorderStroke(3.dp, Color.Black),
                        colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                    ) { Text("NEW GAME", fontWeight = FontWeight.Black) }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
