package com.sebachao.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface GameEvent {
    data class Eliminated(val names: List<String>) : GameEvent
    object Won : GameEvent
    object Draw : GameEvent
    data class Message(val text: String) : GameEvent
}

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val sounds = SoundPlayer()

    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _events = MutableSharedFlow<GameEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<GameEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            val s = withContext(Dispatchers.IO) { repo.load() }
            _state.value = s
            _loaded.value = true
        }
    }

    private fun commit(s: GameState) {
        _state.value = s
        repo.save(s)
    }

    private fun msg(t: String) {
        _events.tryEmit(GameEvent.Message(t))
    }

    fun rename(id: Int, name: String) {
        val cur = _state.value
        commit(cur.copy(roster = cur.roster.map { if (it.id == id) it.copy(name = name) else it }))
    }

    fun toggleSound() {
        val cur = _state.value
        commit(cur.copy(soundOn = !cur.soundOn))
    }

    fun toggleStickers() {
        val cur = _state.value
        commit(cur.copy(stickersOn = !cur.stickersOn))
    }

    /** Returns an error message, or null on success. Safe against double submission. */
    fun addRound(expectedRound: Int, scores: Map<Int, Int>): String? {
        val cur = _state.value
        if (cur.matchOver) return "The match is over. Start a New Game!"
        if (cur.round != expectedRound) return "That round was already added."
        for (p in cur.active) {
            val v = scores[p.id]
            if (v == null || v < 0) return "Enter a score (0 or more) for ${p.displayName}."
        }
        val next = cur.copy(
            roster = cur.roster.map { p ->
                if (p.id < cur.count && !cur.isOut(p)) {
                    p.copy(history = p.history + Entry(cur.round, scores.getValue(p.id)))
                } else p
            },
            round = cur.round + 1
        )
        commit(next)
        val newlyOut = next.players
            .filter { n -> next.isOut(n) && !cur.isOut(cur.roster.first { it.id == n.id }) }
            .map { it.displayName }
        if (newlyOut.isNotEmpty()) _events.tryEmit(GameEvent.Eliminated(newlyOut))
        if (next.matchOver) _events.tryEmit(if (next.isDraw) GameEvent.Draw else GameEvent.Won)
        if (cur.soundOn) {
            when {
                next.winner != null -> sounds.play("win", cur.sounds["win"])
                newlyOut.isNotEmpty() -> sounds.play("out", cur.sounds["out"])
                else -> sounds.play("add", cur.sounds["add"])
            }
        }
        return null
    }

    /** Clears match data only. Names, photos, banner, stickers and sounds are preserved. */
    fun newGame(count: Int, max: Int) {
        val cur = _state.value
        commit(
            cur.copy(
                roster = cur.roster.map { it.copy(history = emptyList()) },
                count = count.coerceIn(MIN_PLAYERS, MAX_PLAYERS),
                maxScore = max.coerceIn(MIN_LIMIT, MAX_LIMIT),
                round = 1
            )
        )
    }

    /** target = -1 for the header banner, 0..11 for a player photo. */
    fun setImage(target: Int, uri: Uri) {
        val ctx = getApplication<Application>()
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
        viewModelScope.launch {
            val stamp = System.currentTimeMillis()
            val fileName = if (target < 0) "banner_$stamp.jpg" else "player${target}_$stamp.jpg"
            val path = withContext(Dispatchers.IO) {
                ImageUtil.importImage(ctx, uri, fileName, if (target < 0) 1600 else 640)
            }
            if (path == null) {
                msg("Couldn't load that image. Please try another one.")
                return@launch
            }
            val cur = _state.value
            val old: String?
            if (target < 0) {
                old = cur.banner
                commit(cur.copy(banner = path))
            } else {
                old = cur.roster[target].photo
                commit(cur.copy(roster = cur.roster.map { if (it.id == target) it.copy(photo = path) else it }))
            }
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
        }
    }

    fun clearBanner() {
        val cur = _state.value
        val old = cur.banner
        commit(cur.copy(banner = null))
        if (old != null) viewModelScope.launch(Dispatchers.IO) { File(old).delete() }
    }

    /** Any image or animated GIF for a sticker slot. The file is copied as-is so GIFs keep animating. */
    fun setSticker(key: String, uri: Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { ImageUtil.copyRaw(ctx, uri, "stk_$key", "png", 25L * 1024 * 1024) }
            if (path == null) {
                msg("Couldn't use that file (max 25 MB). Try another image or GIF.")
                return@launch
            }
            val cur = _state.value
            val old = cur.stickers[key]
            commit(cur.copy(stickers = cur.stickers + (key to path)))
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
        }
    }

    fun clearSticker(key: String) {
        val cur = _state.value
        val old = cur.stickers[key] ?: return
        commit(cur.copy(stickers = cur.stickers - key))
        viewModelScope.launch(Dispatchers.IO) { File(old).delete() }
    }

    /** kind = "add", "out" or "win". The MP3 is copied into app storage and plays in full. */
    fun setSound(kind: String, uri: Uri) {
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { ImageUtil.copyRaw(ctx, uri, "snd_$kind", "mp3", 30L * 1024 * 1024) }
            if (path == null) {
                msg("Couldn't use that audio file (max 30 MB).")
                return@launch
            }
            val cur = _state.value
            val old = cur.sounds[kind]
            commit(cur.copy(sounds = cur.sounds + (kind to path)))
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
            sounds.play(kind, path)
        }
    }

    fun clearSound(kind: String) {
        val cur = _state.value
        val old = cur.sounds[kind] ?: return
        commit(cur.copy(sounds = cur.sounds - kind))
        viewModelScope.launch(Dispatchers.IO) { File(old).delete() }
    }

    fun previewSound(kind: String) {
        sounds.play(kind, _state.value.sounds[kind])
    }

    override fun onCleared() {
        sounds.release()
        super.onCleared()
    }
}

object ImageUtil {
    /** Decodes, rotates (EXIF) and downsizes a photo into app storage. Used for photos and the banner. */
    fun importImage(ctx: Context, uri: Uri, fileName: String, maxSide: Int): String? {
        try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val degrees: Float = try {
                cr.openInputStream(uri)?.use { s ->
                    when (ExifInterface(s).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
                    )) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (e: Exception) {
                0f
            }
            val scale = minOf(1f, maxSide.toFloat() / maxOf(decoded.width, decoded.height))
            val result: Bitmap = if (degrees != 0f || scale < 1f) {
                val m = Matrix()
                m.postRotate(degrees)
                m.postScale(scale, scale)
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
            } else decoded
            val f = File(ctx.filesDir, fileName)
            f.outputStream().use { result.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            return f.absolutePath
        } catch (e: Throwable) {
            return null
        }
    }

    /** Copies a picked file byte-for-byte (keeps GIF animation and PNG transparency, or an MP3). */
    fun copyRaw(ctx: Context, uri: Uri, prefix: String, defaultExt: String, maxBytes: Long): String? {
        try {
            val cr = ctx.contentResolver
            val mime = cr.getType(uri) ?: ""
            val ext = when {
                mime.contains("gif") -> "gif"
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
                mime.contains("mpeg") || mime.contains("mp3") -> "mp3"
                mime.contains("wav") -> "wav"
                mime.contains("ogg") -> "ogg"
                mime.contains("mp4") || mime.contains("aac") -> "m4a"
                else -> defaultExt
            }
            val f = File(ctx.filesDir, "${prefix}_${System.currentTimeMillis()}.$ext")
            val input = cr.openInputStream(uri) ?: return null
            input.use { ins -> f.outputStream().use { outs -> ins.copyTo(outs) } }
            if (f.length() <= 0L || f.length() > maxBytes) {
                f.delete()
                return null
            }
            return f.absolutePath
        } catch (e: Throwable) {
            return null
        }
    }
}

/** Plays the user's MP3 in full, or falls back to built-in synthesised beeps. */
class SoundPlayer {
    private val handler = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private val tg: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 70)
    } catch (e: Throwable) {
        null
    }

    fun play(kind: String, path: String?) {
        stop()
        if (path != null && File(path).exists()) {
            var m: MediaPlayer? = null
            try {
                m = MediaPlayer()
                m.setDataSource(path)
                m.setOnCompletionListener { p ->
                    try {
                        p.release()
                    } catch (e: Throwable) {
                    }
                    if (mp === p) mp = null
                }
                m.setOnErrorListener { p, _, _ ->
                    try {
                        p.release()
                    } catch (e: Throwable) {
                    }
                    if (mp === p) mp = null
                    true
                }
                m.prepare()
                m.start()
                mp = m
                return
            } catch (e: Throwable) {
                try {
                    m?.release()
                } catch (e2: Throwable) {
                }
            }
        }
        when (kind) {
            "add" -> seq(intArrayOf(ToneGenerator.TONE_PROP_BEEP), 0L, 150)
            "out" -> seq(
                intArrayOf(ToneGenerator.TONE_DTMF_9, ToneGenerator.TONE_DTMF_6, ToneGenerator.TONE_DTMF_3, ToneGenerator.TONE_DTMF_0),
                200L, 170
            )
            else -> seq(
                intArrayOf(
                    ToneGenerator.TONE_DTMF_1, ToneGenerator.TONE_DTMF_4, ToneGenerator.TONE_DTMF_7,
                    ToneGenerator.TONE_DTMF_S, ToneGenerator.TONE_DTMF_7, ToneGenerator.TONE_DTMF_S
                ),
                170L, 150
            )
        }
    }

    private fun seq(tones: IntArray, gap: Long, dur: Int) {
        tones.forEachIndexed { i, t ->
            handler.postDelayed({
                try {
                    tg?.startTone(t, dur)
                } catch (e: Throwable) {
                }
            }, i * gap)
        }
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        val m = mp
        mp = null
        if (m != null) {
            try {
                m.stop()
            } catch (e: Throwable) {
            }
            try {
                m.release()
            } catch (e: Throwable) {
            }
        }
    }

    fun release() {
        stop()
        try {
            tg?.release()
        } catch (e: Throwable) {
        }
    }
}
