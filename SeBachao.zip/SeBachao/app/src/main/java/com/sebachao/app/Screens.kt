package com.sebachao.app

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen(
    vm: GameViewModel,
    state: GameState,
    onPickImage: (String) -> Unit,
    onNewGame: () -> Unit,
    onSettings: () -> Unit
) {
    var showRound by remember { mutableStateOf(false) }
    var historyId by remember { mutableStateOf<Int?>(null) }
    var elimNames by remember { mutableStateOf<List<String>?>(null) }
    var showWinner by remember { mutableStateOf(false) }
    var pendingWinner by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.events.collect { e ->
            when (e) {
                is GameEvent.Eliminated -> elimNames = e.names
                is GameEvent.Won, is GameEvent.Draw -> if (elimNames != null) pendingWinner = true else showWinner = true
                is GameEvent.Message -> {}
            }
        }
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            BottomBar(
                state,
                onAdd = { showRound = true },
                onNew = onNewGame,
                onWinner = { showWinner = true }
            )
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 14.dp, end = 14.dp,
                top = pad.calculateTopPadding() + 4.dp,
                bottom = pad.calculateBottomPadding() + 16.dp
            ),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Header(state, onPickBanner = { onPickImage("banner") })
            }
            item(span = { GridItemSpan(maxLineSpan) }) { RoundBar(state, onSettings) }
            itemsIndexed(state.players, key = { _, p -> p.id }) { index, p ->
                PlayerCard(
                    p = p,
                    out = state.isOut(p),
                    max = state.maxScore,
                    index = index,
                    onPhoto = { onPickImage("p:${p.id}") },
                    onRename = { vm.rename(p.id, it) },
                    onHistory = { historyId = p.id }
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) { StatusFooter(state) }
        }
    }

    if (showRound) {
        RoundDialog(
            state = state,
            onDismiss = { showRound = false },
            onSubmit = { map ->
                val r = vm.addRound(state.round, map)
                if (r == null) showRound = false
                r
            }
        )
    }
    val hid = historyId
    if (hid != null && hid < state.roster.size) {
        HistoryDialog(state, state.roster[hid], onDismiss = { historyId = null })
    }
    val en = elimNames
    if (en != null) {
        EliminationDialog(state, en) {
            elimNames = null
            if (pendingWinner) {
                pendingWinner = false
                showWinner = true
            }
        }
    }
    if (showWinner && state.matchOver) {
        WinnerDialog(state, onClose = { showWinner = false }, onNewGame = {
            showWinner = false
            onNewGame()
        })
    }
}

@Composable
fun BottomBar(state: GameState, onAdd: () -> Unit, onNew: () -> Unit, onWinner: () -> Unit) {
    val over = state.matchOver
    Surface(color = Bg1, shadowElevation = 12.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = if (over) onWinner else onAdd,
                modifier = Modifier.weight(1.5f).height(56.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(3.dp, Color.Black),
                colors = ButtonDefaults.buttonColors(containerColor = Amber, contentColor = Dark)
            ) {
                Text(
                    if (!over) "ADD ROUND" else if (state.isDraw) "RESULT" else "WINNER",
                    fontWeight = FontWeight.Black, fontSize = 20.sp
                )
            }
            Button(
                onClick = onNew,
                modifier = Modifier.weight(1f).height(56.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(3.dp, Pink),
                colors = ButtonDefaults.buttonColors(containerColor = CardC, contentColor = Ink),
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) { Text("NEW GAME", fontWeight = FontWeight.Black, fontSize = 16.sp, maxLines = 1) }
        }
    }
}

@Composable
fun Header(state: GameState, onPickBanner: () -> Unit) {
    val bmp = rememberBitmap(state.banner)
    val shape = RoundedCornerShape(22.dp)
    val digits = state.maxScore.toString().length
    val numSize = when {
        digits <= 2 -> 84.sp
        digits == 3 -> 74.sp
        else -> 54.sp
    }
    Box(Modifier.fillMaxWidth().height(164.dp)) {
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(124.dp)
                .clip(shape)
                .background(Brush.linearGradient(listOf(Wine, Color(0xFF4A0A22))))
                .border(4.dp, Pink, shape)
                .clickable(onClick = onPickBanner)
        ) {
            if (bmp != null) {
                Image(
                    bitmap = bmp, contentDescription = "Header banner",
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
                Box(Modifier.fillMaxSize().background(Color(0x66000000)))
            }
            Column(Modifier.align(Alignment.CenterStart).padding(start = 14.dp)) {
                OutlineText("${state.maxScore}", numSize, Yellow)
                OutlineText("SE BACHAO!", 26.sp, Ink, outline = 2.dp, modifier = Modifier.offset(y = (-6).dp))
            }
        }
        if (state.stickersOn) {
            Row(
                Modifier.align(Alignment.BottomEnd).padding(end = 12.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                StickerView(state, Slot.HEAD1, Modifier.size(width = 124.dp, height = 150.dp).wiggle(1300, 4f))
                StickerView(
                    state, Slot.HEAD2,
                    Modifier.offset(x = (-12).dp).size(width = 84.dp, height = 150.dp).wiggle(1300, 4f, 350)
                )
            }
        }
    }
}

@Composable
fun RoundBar(state: GameState, onSettings: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(Modifier.fillMaxWidth()) {
        Box(Modifier.matchParentSize().offset(4.dp, 4.dp).background(Color.Black, shape))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(CardC)
                .border(3.dp, Pink, shape)
                .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (state.matchOver) "MATCH OVER" else "ROUND ${state.round}",
                    color = Yellow, fontSize = 24.sp, fontWeight = FontWeight.Black
                )
                Text(
                    "${state.roundsPlayed} played  •  ${state.active.size} of ${state.count} alive",
                    color = Ink, fontSize = 12.sp
                )
            }
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Bg1)
                    .border(3.dp, Pink, CircleShape)
                    .clickable(onClick = onSettings),
                contentAlignment = Alignment.Center
            ) { Text("⚙", color = Yellow, fontSize = 24.sp) }
        }
    }
}

@Composable
fun StatusFooter(state: GameState) {
    val w = state.winner
    val text = when {
        w != null -> "🏆 ${w.displayName} wins the match!"
        state.isDraw -> "🤝 Everyone's out. No winner this time!"
        state.roundsPlayed == 0 -> "No rounds yet. Tap ADD ROUND to deal the first hand!"
        else -> "Still alive: " + state.active.joinToString { it.displayName }
    }
    Text(
        text, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center
    )
}

@Composable
fun StatusChip(out: Boolean, modifier: Modifier = Modifier) {
    Text(
        if (out) "OUT" else "ACTIVE",
        color = if (out) Color.White else Color(0xFF06210F),
        fontWeight = FontWeight.Black, fontSize = 11.sp,
        modifier = modifier
            .background(if (out) Red else Green, RoundedCornerShape(50))
            .border(2.dp, Color.Black, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 2.dp)
    )
}

@Composable
fun PlayerCard(
    p: Player,
    out: Boolean,
    max: Int,
    index: Int,
    onPhoto: () -> Unit,
    onRename: (String) -> Unit,
    onHistory: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    val stamp by animateFloatAsState(
        if (out) 1f else 3f, spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "stamp"
    )
    val animScore by animateIntAsState(p.total, tween(700), label = "score")
    var text by remember(p.id) { mutableStateOf(p.name) }
    val frac = (p.total / max.toFloat()).coerceIn(0f, 1f)
    val barColor = when {
        out -> Red
        frac >= 0.8f -> Red
        frac >= 0.6f -> Amber
        else -> Green
    }
    Box(Modifier.fillMaxWidth().graphicsLayer { rotationZ = if (index % 2 == 0) -1.2f else 1.2f }) {
        Box(Modifier.matchParentSize().offset(5.dp, 5.dp).background(Color.Black, shape))
        Box(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(if (out) Color(0xFF2A0F16) else CardC)
                .border(3.dp, if (out) Red else Pink, shape)
        ) {
            Column(
                Modifier.padding(10.dp).alpha(if (out) 0.55f else 1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Avatar(p.photo, p.id, 96.dp, Modifier.clickable(onClick = onPhoto), showBadge = true)
                StatusChip(out, Modifier.offset(y = (-12).dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it.take(14); onRename(text) },
                        singleLine = true,
                        textStyle = TextStyle(
                            color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(Yellow),
                        modifier = Modifier.weight(1f)
                    )
                    Text("✎", color = Ink.copy(alpha = 0.7f), fontSize = 13.sp)
                }
                Text(
                    "$animScore",
                    color = if (out) Red else Yellow, fontSize = 42.sp,
                    fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(50))
                        .border(2.dp, Color.Black, RoundedCornerShape(50))
                        .background(Color(0x33FFFFFF))
                ) {
                    Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(barColor))
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onHistory,
                    modifier = Modifier.fillMaxWidth().height(38.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(3.dp, Color.Black),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink, contentColor = Dark)
                ) { Text("History", fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Clip) }
            }
            if (out) {
                Text(
                    "OUT",
                    color = Red, fontSize = 46.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .graphicsLayer { rotationZ = -18f; scaleX = stamp; scaleY = stamp }
                        .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                        .border(5.dp, Red, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 2.dp)
                )
            }
        }
    }
}
