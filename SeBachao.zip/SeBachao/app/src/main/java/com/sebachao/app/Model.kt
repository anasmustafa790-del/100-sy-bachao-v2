package com.sebachao.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

const val MAX_PLAYERS = 12
const val MIN_PLAYERS = 2
const val DEFAULT_LIMIT = 100
const val MIN_LIMIT = 10
const val MAX_LIMIT = 9999

data class Entry(val round: Int, val score: Int)

data class Player(
    val id: Int,
    val name: String,
    val photo: String? = null,
    val history: List<Entry> = emptyList()
) {
    val total: Int get() = history.sumOf { it.score }
    val displayName: String get() = name.trim().ifBlank { "Player ${id + 1}" }
}

/** Every place in the app that shows a sticker. Each can be replaced by the user (image or GIF). */
enum class Slot(val key: String, val label: String, val res: Int) {
    HEAD1("head1", "Header sticker 1", R.drawable.st_duo),
    HEAD2("head2", "Header sticker 2", R.drawable.st_paisley),
    OUT("out", "OUT screen", R.drawable.st_lingerie),
    WIN_L("winl", "WIN screen - left", R.drawable.st_redgun),
    WIN_C("winc", "WIN screen - center", R.drawable.st_water),
    WIN_R("winr", "WIN screen - right", R.drawable.st_denim)
}

data class GameState(
    val roster: List<Player> = List(MAX_PLAYERS) { Player(it, "Player ${it + 1}") },
    val count: Int = 6,
    val maxScore: Int = DEFAULT_LIMIT,
    val round: Int = 1,
    val banner: String? = null,
    val soundOn: Boolean = true,
    val stickersOn: Boolean = true,
    val stickers: Map<String, String> = emptyMap(),
    val sounds: Map<String, String> = emptyMap()
) {
    val players: List<Player> get() = roster.take(count)
    fun isOut(p: Player): Boolean = p.total >= maxScore
    fun outRound(p: Player): Int? {
        var s = 0
        for (e in p.history) {
            s += e.score
            if (s >= maxScore) return e.round
        }
        return null
    }
    val active: List<Player> get() = players.filter { !isOut(it) }
    val roundsPlayed: Int get() = round - 1
    val matchOver: Boolean get() = roundsPlayed > 0 && active.size <= 1
    val winner: Player? get() = if (matchOver && active.size == 1) active[0] else null
    val isDraw: Boolean get() = matchOver && active.isEmpty()
}

/** Local, offline persistence (SharedPreferences + JSON). Survives app restarts and reboots. */
class Repo(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("se_bachao_store_v2", Context.MODE_PRIVATE)

    private fun mapToJson(m: Map<String, String>): JSONObject {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        return o
    }

    private fun jsonToMap(o: JSONObject?): Map<String, String> {
        if (o == null) return emptyMap()
        val r = mutableMapOf<String, String>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = o.optString(k, "")
            if (v.isNotBlank()) r[k] = v
        }
        return r
    }

    fun save(g: GameState) {
        val arr = JSONArray()
        for (p in g.roster) {
            val h = JSONArray()
            for (e in p.history) h.put(JSONObject().put("r", e.round).put("s", e.score))
            arr.put(JSONObject().put("name", p.name).put("photo", p.photo ?: "").put("history", h))
        }
        val o = JSONObject()
            .put("players", arr)
            .put("count", g.count)
            .put("max", g.maxScore)
            .put("banner", g.banner ?: "")
            .put("sound", g.soundOn)
            .put("stickersOn", g.stickersOn)
            .put("stickers", mapToJson(g.stickers))
            .put("sounds", mapToJson(g.sounds))
        prefs.edit().putString("state", o.toString()).apply()
    }

    fun load(): GameState {
        val raw = prefs.getString("state", null) ?: return GameState()
        return try {
            val o = JSONObject(raw)
            val arr = o.getJSONArray("players")
            val roster = (0 until MAX_PLAYERS).map { i ->
                if (i >= arr.length()) {
                    Player(i, "Player ${i + 1}")
                } else {
                    val po = arr.getJSONObject(i)
                    val h = po.optJSONArray("history") ?: JSONArray()
                    val entries = (0 until h.length()).map { j ->
                        val e = h.getJSONObject(j)
                        Entry(e.getInt("r"), e.getInt("s"))
                    }
                    val photo: String? = po.optString("photo", "").ifBlank { null }
                    Player(i, po.optString("name", "Player ${i + 1}"), photo, entries)
                }
            }
            val maxRound = roster.flatMap { it.history }.maxOfOrNull { it.round } ?: 0
            val banner: String? = o.optString("banner", "").ifBlank { null }
            GameState(
                roster = roster,
                count = o.optInt("count", 6).coerceIn(MIN_PLAYERS, MAX_PLAYERS),
                maxScore = o.optInt("max", DEFAULT_LIMIT).coerceIn(MIN_LIMIT, MAX_LIMIT),
                round = maxRound + 1,
                banner = banner,
                soundOn = o.optBoolean("sound", true),
                stickersOn = o.optBoolean("stickersOn", true),
                stickers = jsonToMap(o.optJSONObject("stickers")),
                sounds = jsonToMap(o.optJSONObject("sounds"))
            )
        } catch (e: Exception) {
            GameState()
        }
    }
}
