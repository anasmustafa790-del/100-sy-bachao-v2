package com.sebachao.app

import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.sin
import kotlin.random.Random

/** Image loader that understands GIFs (set in MainActivity). */
val LocalLoader = staticCompositionLocalOf<ImageLoader> { error("ImageLoader not provided") }

/** Shows the user's custom image/GIF for a slot, or the built-in sticker. */
@Composable
fun StickerView(state: GameState, slot: Slot, modifier: Modifier = Modifier) {
    val path = state.stickers[slot.key]
    val model: Any = if (path != null) File(path) else slot.res
    AsyncImage(
        model = model,
        contentDescription = null,
        imageLoader = LocalLoader.current,
        error = painterResource(slot.res),
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
fun Modifier.wiggle(periodMs: Int = 1200, amp: Float = 4f, offsetMs: Int = 0): Modifier {
    val t = rememberInfiniteTransition(label = "wiggle")
    val a by t.animateFloat(
        initialValue = -amp,
        targetValue = amp,
        animationSpec = infiniteRepeatable(
            animation = tween(periodMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
            initialStartOffset = StartOffset(offsetMs)
        ),
        label = "wiggleAngle"
    )
    return this.graphicsLayer {
        rotationZ = a
        transformOrigin = TransformOrigin(0.5f, 1f)
    }
}

@Composable
fun rememberTime(): State<Float> {
    val t = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { t.floatValue = (it - start) / 1_000_000_000f }
        }
    }
    return t
}

/** Cartoon text with a thick black outline. */
@Composable
fun OutlineText(
    text: String,
    size: TextUnit,
    color: Color,
    modifier: Modifier = Modifier,
    outline: Dp = 3.dp,
    italic: Boolean = false
) {
    val style = if (italic) FontStyle.Italic else FontStyle.Normal
    Box(modifier) {
        val offs = listOf(-1 to -1, 1 to -1, -1 to 1, 1 to 1, 0 to 2, 0 to -1, -1 to 0, 1 to 0)
        for ((dx, dy) in offs) {
            Text(
                text, fontSize = size, fontWeight = FontWeight.Black, fontStyle = style,
                color = Color.Black, modifier = Modifier.offset(outline * dx, outline * dy)
            )
        }
        Text(text, fontSize = size, fontWeight = FontWeight.Black, fontStyle = style, color = color)
    }
}

/** Loads a saved photo file off the main thread. Null while loading or if the file is missing. */
@Composable
fun rememberBitmap(path: String?): ImageBitmap? {
    var bmp by remember(path) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(path) {
        bmp = if (path == null) null else withContext(Dispatchers.IO) {
            try {
                BitmapFactory.decodeFile(path)?.asImageBitmap()
            } catch (e: Throwable) {
                null
            }
        }
    }
    return bmp
}

private val fallbackEmoji = listOf("🤠", "😎", "🧐", "🤓", "🥸", "😜", "🤩", "😏", "🥳", "😈", "🤑", "🦸")

@Composable
fun Avatar(
    path: String?,
    id: Int,
    diameter: Dp,
    modifier: Modifier = Modifier,
    showBadge: Boolean = false,
    ring: Color = Pink
) {
    val bmp = rememberBitmap(path)
    Box(modifier.size(diameter)) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF5A2040), Color(0xFF2A0F1E)))),
            contentAlignment = Alignment.Center
        ) {
            if (bmp != null) {
                Image(
                    bitmap = bmp, contentDescription = "Player photo",
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
            } else {
                Text(fallbackEmoji[id % fallbackEmoji.size], fontSize = (diameter.value * 0.5f).sp)
            }
        }
        Box(Modifier.fillMaxSize().border(4.dp, ring, CircleShape))
        if (showBadge) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .size(28.dp)
                    .background(Yellow, CircleShape)
                    .border(2.dp, Color.Black, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("📷", fontSize = 13.sp) }
        }
    }
}

@Composable
fun MiniCard(rank: String, suit: String, red: Boolean, modifier: Modifier = Modifier, rotation: Float = 0f) {
    val c = if (red) Color(0xFFD81F1F) else Color(0xFF1A1A2E)
    val shape = RoundedCornerShape(7.dp)
    Box(
        modifier
            .graphicsLayer { rotationZ = rotation }
            .size(width = 46.dp, height = 64.dp)
            .background(Cream, shape)
            .border(2.dp, Color(0xFF1A1A2E), shape),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(rank, color = c, fontWeight = FontWeight.Black, fontSize = 15.sp)
            Text(suit, color = c, fontSize = 20.sp)
        }
    }
}

@Composable
fun PokerChip(diameter: Dp, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(diameter)) {
        val r = this.size.minDimension / 2f
        val c = Offset(r, r)
        drawCircle(color, radius = r, center = c)
        drawCircle(
            Cream, radius = r * 0.8f, center = c,
            style = Stroke(r * 0.16f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(r * 0.35f, r * 0.28f)))
        )
        drawCircle(color, radius = r * 0.55f, center = c)
        drawCircle(Amber, radius = r * 0.55f, center = c, style = Stroke(r * 0.07f))
    }
}

@Composable
fun Crown(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 76.dp, height = 50.dp)) {
        val w = this.size.width
        val h = this.size.height
        val p = Path().apply {
            moveTo(w * 0.08f, h * 0.92f)
            lineTo(w * 0.14f, h * 0.2f)
            lineTo(w * 0.36f, h * 0.55f)
            lineTo(w * 0.5f, h * 0.05f)
            lineTo(w * 0.64f, h * 0.55f)
            lineTo(w * 0.86f, h * 0.2f)
            lineTo(w * 0.92f, h * 0.92f)
            close()
        }
        drawPath(p, Amber)
        drawPath(p, Color.Black, style = Stroke(width = 6f, join = StrokeJoin.Round))
    }
}

private class Part(
    val x: Float, val y0: Float, val speed: Float, val size: Float,
    val rot0: Float, val spin: Float, val color: Color, val kind: Int
)

/** mode 0 = confetti and chips (win). mode 1 = falling playing cards (out). */
@Composable
fun Falling(mode: Int, modifier: Modifier = Modifier) {
    val colors = listOf(Yellow, Pink, Cream, Green, Color(0xFF27E1FF), Red)
    val parts = remember(mode) {
        List(if (mode == 1) 12 else 60) {
            Part(
                Random.nextFloat(), Random.nextFloat(), 0.12f + Random.nextFloat() * 0.25f,
                if (mode == 1) 1f + Random.nextFloat() * 0.6f else 9f + Random.nextFloat() * 10f,
                Random.nextFloat() * 360f, (Random.nextFloat() - 0.5f) * 360f,
                colors[Random.nextInt(colors.size)], Random.nextInt(2)
            )
        }
    }
    val t by rememberTime()
    Canvas(modifier) {
        val sz = this.size
        for (p in parts) {
            val y = ((p.y0 + p.speed * t) % 1.12f) - 0.06f
            val x = p.x * sz.width + sin(t * 1.5f + p.rot0) * 14f
            val py = y * sz.height
            val deg = p.rot0 + p.spin * t
            if (mode == 1) {
                val w = 30f * p.size
                val h = 42f * p.size
                rotate(deg, pivot = Offset(x, py)) {
                    drawRoundRect(Cream, Offset(x - w / 2, py - h / 2), Size(w, h), CornerRadius(6f))
                    drawRoundRect(Color(0xFF1A1A2E), Offset(x - w / 2, py - h / 2), Size(w, h), CornerRadius(6f), style = Stroke(3f))
                    drawCircle(if (p.kind == 0) Color(0xFFD81F1F) else Color(0xFF1A1A2E), radius = w * 0.2f, center = Offset(x, py))
                }
            } else if (p.kind == 0) {
                rotate(deg, pivot = Offset(x, py)) {
                    drawRect(p.color, Offset(x, py), Size(p.size, p.size * 0.6f))
                }
            } else {
                val r = p.size * 0.9f
                drawCircle(p.color, radius = r, center = Offset(x, py))
                drawCircle(Cream, radius = r * 0.65f, center = Offset(x, py), style = Stroke(r * 0.22f))
            }
        }
    }
}

@Composable
fun Rays(modifier: Modifier = Modifier) {
    val t by rememberTime()
    Canvas(modifier) {
        val c = Offset(this.size.width / 2f, this.size.height * 0.3f)
        val r = this.size.maxDimension
        for (i in 0 until 18) {
            drawArc(
                Amber.copy(alpha = 0.18f), startAngle = i * 20f + t * 12f, sweepAngle = 10f, useCenter = true,
                topLeft = Offset(c.x - r, c.y - r), size = Size(2f * r, 2f * r)
            )
        }
    }
}

/** Casino chips and playing cards scattered in the background. */
@Composable
fun BackgroundDeco() {
    Box(Modifier.fillMaxSize()) {
        PokerChip(64.dp, Red, Modifier.align(Alignment.TopStart).offset((-20).dp, 170.dp).alpha(0.45f))
        PokerChip(54.dp, Color(0xFF1F6FEB), Modifier.align(Alignment.TopEnd).offset(14.dp, 300.dp).alpha(0.4f))
        MiniCard("A", "♠", false, Modifier.align(Alignment.CenterStart).offset((-16).dp, 40.dp).alpha(0.4f), -18f)
        MiniCard("K", "♥", true, Modifier.align(Alignment.CenterEnd).offset(16.dp, 120.dp).alpha(0.4f), 16f)
        PokerChip(58.dp, Green, Modifier.align(Alignment.BottomStart).offset((-18).dp, (-150).dp).alpha(0.4f))
        MiniCard("Q", "♦", true, Modifier.align(Alignment.BottomEnd).offset(14.dp, (-190).dp).alpha(0.4f), -12f)
        PokerChip(48.dp, Amber, Modifier.align(Alignment.TopEnd).offset(10.dp, 120.dp).alpha(0.35f))
        MiniCard("J", "♣", false, Modifier.align(Alignment.TopStart).offset((-14).dp, 300.dp).alpha(0.35f), 14f)
    }
}
