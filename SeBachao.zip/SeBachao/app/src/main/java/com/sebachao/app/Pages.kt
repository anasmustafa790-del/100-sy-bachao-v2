package com.sebachao.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PageTitle(title: String, sub: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(CardC)
                    .border(3.dp, Pink, CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) { Text("‹", color = Yellow, fontSize = 28.sp, fontWeight = FontWeight.Black) }
            Spacer(Modifier.width(12.dp))
            OutlineText(title, 36.sp, Yellow)
        }
        Spacer(Modifier.height(4.dp))
        Text(sub, color = Ink, fontSize = 13.sp)
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(modifier.fillMaxWidth().padding(bottom = 14.dp)) {
        Box(Modifier.matchParentSize().offset(5.dp, 5.dp).background(Color.Black, shape))
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(CardC)
                .border(3.dp, Pink, shape)
                .padding(14.dp),
            content = content
        )
    }
}

@Composable
fun PanelLabel(text: String) {
    Text(text, color = Yellow, fontWeight = FontWeight.Black, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
fun PopButton(
    text: String,
    modifier: Modifier = Modifier,
    container: Color = Amber,
    content: Color = Dark,
    border: Color = Color.Black,
    enabled: Boolean = true,
    height: Int = 50,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(height.dp),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(3.dp, border),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content),
        contentPadding = PaddingValues(horizontal = 12.dp)
    ) { Text(text, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 1) }
}

@Composable
fun NewGameScreen(state: GameState, onStart: (Int, Int) -> Unit, onCancel: () -> Unit) {
    var count by rememberSaveable { mutableStateOf(state.count) }
    var maxText by rememberSaveable { mutableStateOf(state.maxScore.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val max = maxText.toIntOrNull()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("NEW GAME", "Set up the match before you deal.", onCancel)
        Panel {
            PanelLabel("HOW MANY PLAYERS? ($MIN_PLAYERS TO $MAX_PLAYERS)")
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                PopButton("−", Modifier.width(60.dp), height = 56) { if (count > MIN_PLAYERS) count-- }
                Text(
                    "$count", color = Yellow, fontSize = 56.sp, fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center, modifier = Modifier.width(100.dp)
                )
                PopButton("+", Modifier.width(60.dp), height = 56) { if (count < MAX_PLAYERS) count++ }
            }
            Spacer(Modifier.height(8.dp))
            for (rowPlayers in state.roster.take(count).chunked(6)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    for (p in rowPlayers) {
                        Avatar(p.photo, p.id, 40.dp, Modifier.padding(3.dp))
                    }
                }
            }
            Text(
                "Saved names and photos are kept. New players get default names.",
                color = Ink, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
        Panel {
            PanelLabel("MAX SCORE (OUT AT OR ABOVE)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (v in listOf(50, 100, 150, 200)) {
                    PopButton(
                        "$v", Modifier.weight(1f),
                        container = if (max == v) Amber else Bg1,
                        content = if (max == v) Dark else Ink,
                        border = if (max == v) Color.Black else Pink
                    ) { maxText = v.toString(); error = null }
                }
            }
            OutlinedTextField(
                value = maxText,
                onValueChange = { maxText = it.filter { c -> c.isDigit() }.take(4); error = null },
                singleLine = true,
                label = { Text("Custom max score") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            )
            Text("Type any number from $MIN_LIMIT to $MAX_LIMIT.", color = Ink, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Panel {
            Text(
                "$count players. Anyone reaching ${max ?: "?"} is OUT. Last one standing wins.",
                color = Ink, fontSize = 13.sp
            )
        }
        val err = error
        if (err != null) {
            Text(err, color = Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
        }
        PopButton("START MATCH", Modifier.fillMaxWidth(), height = 56) {
            if (max == null || max < MIN_LIMIT || max > MAX_LIMIT) {
                error = "Max score must be between $MIN_LIMIT and $MAX_LIMIT."
            } else if (state.roundsPlayed > 0) {
                confirm = true
            } else {
                onStart(count, max)
            }
        }
        Spacer(Modifier.height(10.dp))
        PopButton("Cancel", Modifier.fillMaxWidth(), container = CardC, content = Ink, border = Pink, height = 52) { onCancel() }
        Spacer(Modifier.height(16.dp))
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = CardC,
            titleContentColor = Yellow,
            textContentColor = Ink,
            title = { Text("New Game?", fontWeight = FontWeight.Black) },
            text = { Text("Start a new game? Current match scores and history will be cleared.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirm = false
                        onStart(count, max ?: DEFAULT_LIMIT)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White)
                ) { Text("Start New Game", fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("Cancel", color = Pink) }
            }
        )
    }
}

@Composable
private fun SoundRow(label: String, custom: Boolean, onPlay: () -> Unit, onPick: () -> Unit, onReset: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, fontWeight = FontWeight.Bold, color = Ink)
        Text(if (custom) "Custom MP3 selected (plays in full)" else "Default beep", color = Pink, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PopButton("Play", container = Bg1, content = Ink, border = Pink, height = 38, onClick = onPlay)
            PopButton("Choose MP3", height = 38, onClick = onPick)
            PopButton("Reset", container = Bg1, content = Ink, border = Pink, enabled = custom, height = 38, onClick = onReset)
        }
    }
}

@Composable
fun SettingsScreen(
    state: GameState,
    vm: GameViewModel,
    onPickSound: (String) -> Unit,
    onPickBanner: () -> Unit,
    onOpenStickers: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("SETTINGS", "Sounds and looks. Everything stays offline.", onBack)
        Panel {
            PanelLabel("SOUNDS")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.soundOn, onCheckedChange = { vm.toggleSound() })
                Spacer(Modifier.width(10.dp))
                Text("Sound effects on", fontWeight = FontWeight.Bold, color = Ink)
            }
            SoundRow("When a round is added", state.sounds.containsKey("add"),
                { vm.previewSound("add") }, { onPickSound("add") }, { vm.clearSound("add") })
            SoundRow("When a player is OUT", state.sounds.containsKey("out"),
                { vm.previewSound("out") }, { onPickSound("out") }, { vm.clearSound("out") })
            SoundRow("When someone wins", state.sounds.containsKey("win"),
                { vm.previewSound("win") }, { onPickSound("win") }, { vm.clearSound("win") })
        }
        Panel {
            PanelLabel("LOOK")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.stickersOn, onCheckedChange = { vm.toggleStickers() })
                Spacer(Modifier.width(10.dp))
                Text("Show stickers", fontWeight = FontWeight.Bold, color = Ink)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PopButton("Header banner photo", Modifier.weight(1f), height = 40, onClick = onPickBanner)
                PopButton(
                    "Reset", container = Bg1, content = Ink, border = Pink,
                    enabled = state.banner != null, height = 40
                ) { vm.clearBanner() }
            }
            Spacer(Modifier.height(10.dp))
            PopButton("EDIT ALL STICKERS", Modifier.fillMaxWidth(), height = 52, onClick = onOpenStickers)
        }
        Text("100 Se Bachao! v2.0", color = Ink.copy(alpha = 0.6f), fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun StickersScreen(
    state: GameState,
    vm: GameViewModel,
    onPickSticker: (String) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        PageTitle("STICKERS", "Pick an image or an animated GIF for each spot.", onBack)
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.stickersOn, onCheckedChange = { vm.toggleStickers() })
                Spacer(Modifier.width(10.dp))
                Text("Show stickers", fontWeight = FontWeight.Bold, color = Ink)
            }
            Spacer(Modifier.height(6.dp))
            for (slot in Slot.values()) {
                val custom = state.stickers.containsKey(slot.key)
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(width = 64.dp, height = 72.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xAA000000))
                            .border(2.dp, Pink, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) { StickerView(state, slot, Modifier.fillMaxSize().padding(2.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(slot.label, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
                        Text(if (custom) "Custom image / GIF" else "Default", color = Pink, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PopButton("Change", height = 36) { onPickSticker(slot.key) }
                            PopButton(
                                "Reset", container = Bg1, content = Ink, border = Pink,
                                enabled = custom, height = 36
                            ) { vm.clearSticker(slot.key) }
                        }
                    }
                }
            }
        }
        Text(
            "PNG, JPG, WEBP or GIF. A transparent PNG or GIF looks best.",
            color = Ink, fontSize = 12.sp
        )
        Spacer(Modifier.height(16.dp))
    }
}
