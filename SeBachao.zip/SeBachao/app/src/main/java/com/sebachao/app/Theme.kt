package com.sebachao.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg1 = Color(0xFF14040C)
val Bg2 = Color(0xFF2A0A1A)
val CardC = Color(0xFF3A1024)
val Pink = Color(0xFFFF7AB6)
val Wine = Color(0xFF8E1236)
val Yellow = Color(0xFFFFE14D)
val Amber = Color(0xFFFFC83D)
val Ink = Color(0xFFFFE9F1)
val Red = Color(0xFFFF3B3B)
val Green = Color(0xFF39E58C)
val Cream = Color(0xFFFFF4DC)
val Dark = Color(0xFF1A1A1A)

@Composable
fun SeBachaoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Amber,
            onPrimary = Dark,
            secondary = Pink,
            background = Bg1,
            surface = CardC,
            onSurface = Ink,
            onBackground = Ink,
            error = Red
        ),
        content = content
    )
}
