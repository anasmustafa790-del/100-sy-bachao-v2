# 100 Se Bachao! v2.0

Offline score tracker. Set the number of players (2 to 12) and the max score for each match. Reach it and you're OUT. Last player standing wins.
Kotlin + Jetpack Compose, minSdk 26 (Android 8.0+). No internet permission, no accounts.

> The first GitHub Actions run is the first real build of v2. If it fails, copy the red error lines and ask for a fix.

## Build the APK from your Android phone
1. github.com in Chrome (menu > Desktop site) > open your repo.
2. **Add file > Upload files** > choose the new `SeBachao.zip` (do NOT unzip). Same file name = it replaces the old ZIP. **Commit changes**.
3. **Actions** tab > wait for the green tick (about 5 to 10 min). If it does not start: Actions > Build APK > Run workflow.
4. Repo home > **Releases** > newest build > tap `100-Se-Bachao-release.apk`.

Install: open the APK, allow "Install unknown apps" if asked, tap Install. Installing over v1 keeps nothing from v1 (new storage), that is normal.

## What's new in v2
* New Game screen: choose 2 to 12 players and any max score (50, 100, 150, 200 or custom 10 to 9999). Names/photos are kept.
* Header shows the big max score with a smaller SE BACHAO!, plus your stickers. Tap the header to change the banner photo.
* Tap a player's photo to change it; tap a name to rename it, any time.
* Settings: sound on/off, your own MP3 for round added / player OUT / winner (plays in full), Play preview, Reset.
* Settings > Edit all stickers: change each of the 6 stickers separately with any image or animated GIF.
* Dark Velvet Red cartoon theme, cards and chips in the background, animated OUT and WIN screens.

Everything is stored on the phone (JSON in SharedPreferences, copied files in app storage).
